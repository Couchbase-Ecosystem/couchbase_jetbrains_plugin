const Orientation = {
  LeftToRight: "Left to Right",
  RightToLeft: "Right to Left",
  TopToBottom: "Top to Bottom",
  BottomToTop: "Bottom to Top",
};
