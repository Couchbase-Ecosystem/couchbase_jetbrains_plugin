const PlanConfig = {
  /** the width and height used to render nodes as dots */
  compactSize: 25,
  /** at what width/height do we automatically toggle between compact mode */
  compactBreakPoint: 400,
};
